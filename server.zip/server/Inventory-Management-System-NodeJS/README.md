# Warehouse Inventory Management

Inventory management system using node js and mysql.

## Install and Run

First install all dependencies

~~~~
npm install
~~~~

Then run the app

~~~~
node app.js
~~~~